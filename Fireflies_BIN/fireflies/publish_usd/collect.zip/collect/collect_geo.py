import os
import pyblish.api

from cgev.common import log

from cgev.pyblish.plugins.maya import export_options

if "DEV" in os.environ and os.environ["DEV"]:
    import importlib

    importlib.reload(export_options)

class CollectMayaGeometry(pyblish.api.ContextPlugin):
    """Collect all geo in the scene"""

    order = pyblish.api.CollectorOrder - 0.5
    label = "Maya geometry"

    hosts = ["maya"]
    version = (0, 1, 0)

    active = True


    def process(self, context):
        import os
        from maya import cmds

        sets = cmds.ls(type="objectSet", long=True)
        geo_sets = [geo_set for geo_set in sets if geo_set.endswith("_GEO")]

        # list all groups that have a subgoup called "geo

        asset_candidates = cmds.ls("*_ASSET", type="transform")
        print(cmds.nodeType(asset_candidates))
        log.debug("Geo assets candidates : {}".format("\n".join(asset_candidates)))

        for asset_candidate in asset_candidates:
            #if we use the first xform in the hierarchy it returns None if we get the children here
            asset_name = cmds.listRelatives(asset_candidate, children=True)
            # asset_name = asset_candidates
            if cmds.nodeType(asset_candidate) != "transform":
                continue
            instance = context.create_instance(asset_candidate)
            # instance = pyblish.api.Instance(name="MAYA_USD")
            instance.data["asset_name"] = asset_candidate
            instance.append("asset_name")
            instance.data["family"] = "geometry"
            # TODO - Perhaps create family classes (if need to set several ext, or more outputs than usd)
            instance.data["usd_ext"] = ".usda"
            instance.data["export_options"] = export_options.GeoMayaUsdExportOptions()
            # instance.data["setMembers"] = cmds.sets(geo_set, query=True)
            # log.info("Members of {0}: {1}".format(geo_set, instance.data["setMembers"]))
            # self.log.info(f"Collected geo instance of asset {asset_name}")
            instance[0] = asset_candidate
            # self.log.debug(instance.data["asset_name"])

            # log.debug(instance[0])

            # - Export options

            instance.data["ExportAnim"] = False
            # instance.data["subset"] = "mesh"

            # instance.data["families"] = ["geometry", "mesh"]
            # instance.data["file"] = cmds.referenceQuery(mesh, filename=True)
            # instance.data["publish"] = True
            # instance.data["outSetMembers"] = [mesh] 

        for instance in context:
            self.log.debug(f"######{instance}")
            self.log.debug(str(instance))
        
